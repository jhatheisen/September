// Put your code in here to make each of the tests described in the HTML file
// pass.

// Your code here
// p1
document.getElementById('bubble-trouble').addEventListener('click', (e) => {
  e.stopPropagation();
});

// p2
const counterSpan = document.getElementById('counter-value');
const incButton = document.getElementById('increment');
const decButton = document.getElementById('decrement');
const zero = document.getElementById('zero-out');

incButton.addEventListener('click', () => {
  counterValue++;
  counterSpan.innerHTML = counterValue;
});

decButton.addEventListener('click', () => {
  counterValue--;
  counterSpan.innerHTML = counterValue;
});

zero.addEventListener('click', () => {
  counterValue = 0;
  counterSpan.innerHTML = counterValue;
});

// p3
const inputBox = document.getElementById('my-name-is');
const storedIn = localStorage.getItem('input');
if (storedIn) {
  inputBox.value = storedIn;
}

inputBox.addEventListener('keyup', key => {
  localStorage.setItem('input', inputBox.value);
});

// p4
const link = document.getElementById('navigates-elsewhere');

link.addEventListener('click', e => {
  e.preventDefault();
});

// p5

const fetchButton = document.getElementById('go-fetch');
const ol = document.getElementById('sub-breed-ol');

fetchButton.addEventListener('click', async () => {
  let data = await fetch('https://dog.ceo/api/breed/terrier/list');
  let json = await data.json();
  let breeds = await json.message;

  breeds.forEach(breed => {
    let list = document.createElement('li');
    list.innerText = breed;

    list.addEventListener('mouseover', e => {
      list.style.color = 'red';
    });
    
    ol.appendChild(list);
  });
});
