if (!fetch) {
  var fetch = require('./test/node-fetch')(1);
}

/**
 * Do not change code above this line.
 * See README.md for instructions

 ******************************************************************************/

async function addPerson() {
  let text = {
    "firstName": "Maul",
    "lastName": "Kimmerman"
  }
  let body = JSON.stringify(text);
  let options = {
    method : 'POST',
    headers: { 'Content-Type' : 'application/json' },
    body : body
  };

  let resBody = await fetch('http://example.com/api/people', options);
  let jsRes = await resBody.json();
  let final = await jsRes;
  
  return final.people;
}

/*******************************************************************************
 * Do not change code below this line.
 */

if (!exports) {
  var exports = {};
}
(function (exports) {
  try {
    exports.addPerson = addPerson;
  } catch (e) {
    exports.addPerson = () => { throw e };
  }
})(exports);
